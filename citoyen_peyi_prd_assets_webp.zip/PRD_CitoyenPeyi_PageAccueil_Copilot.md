# PRD ultra précis — Page Accueil Citoyen Peyi

## 0. Objectif du fichier

Ce document est le fichier unique à fournir à Copilot pour recréer la page d’accueil **Citoyen Peyi** à l’identique, avec une interface simplifiée, institutionnelle, premium, et tous les assets nécessaires en **WebP**.

La page doit reprendre la maquette validée avec :

- logo **Citoyen Peyi** en haut, sans fond blanc ;
- fond bleu dégradé avec cercles transparents ;
- pastille “Plateforme de consultation citoyenne anonyme” ;
- encadré jaune remonté ;
- trois boutons principaux ;
- ajout d’un bouton **Super administrateur** ;
- barre de navigation basse blanche ;
- aucun texte explicatif long ;
- aucune réapparition du grand titre “Votez en toute confidentialité”.

---

## 1. Canvas de référence

Base de design obligatoire :

```text
Largeur : 1448 px
Hauteur : 1086 px
Ratio : tablette / web large
```

Dans Flutter, travailler avec une échelle proportionnelle :

```dart
const double designWidth = 1448;
const double designHeight = 1086;
final scale = min(
  constraints.maxWidth / designWidth,
  constraints.maxHeight / designHeight,
);
```

La page doit tenir entièrement sans scroll sur tablette, desktop et web.

---

## 2. Arborescence obligatoire des assets

Tous les fichiers image créés doivent être en `.webp`.

```text
assets/
  citoyen_peyi/
    home_background.webp
    logo_citoyen_peyi_transparent.webp
    icon_admin.webp
    icon_controller.webp
    icon_citizen.webp
    icon_super_admin.webp
    nav_home.webp
    nav_opinion.webp
    nav_results.webp
    nav_news.webp
    nav_profile.webp
    reference_page_accueil.webp
```

Déclaration dans `pubspec.yaml` :

```yaml
flutter:
  assets:
    - assets/citoyen_peyi/home_background.webp
    - assets/citoyen_peyi/logo_citoyen_peyi_transparent.webp
    - assets/citoyen_peyi/icon_admin.webp
    - assets/citoyen_peyi/icon_controller.webp
    - assets/citoyen_peyi/icon_citizen.webp
    - assets/citoyen_peyi/icon_super_admin.webp
    - assets/citoyen_peyi/nav_home.webp
    - assets/citoyen_peyi/nav_opinion.webp
    - assets/citoyen_peyi/nav_results.webp
    - assets/citoyen_peyi/nav_news.webp
    - assets/citoyen_peyi/nav_profile.webp
    - assets/citoyen_peyi/reference_page_accueil.webp
```

---

## 3. Règle absolue sur le logo

Fichier :

```text
assets/citoyen_peyi/logo_citoyen_peyi_transparent.webp
```

Le logo doit être transparent.

Interdictions :

- aucun rectangle blanc ;
- aucun fond opaque ;
- aucun halo blanc autour du logo ;
- aucune carte blanche derrière le logo ;
- aucune ombre de bloc.

Le logo doit être posé directement sur le fond bleu.

Position d’affichage :

```text
Top : 90 px
Largeur : 500 px
Hauteur : 120 px
Alignement : centré
```

Code :

```dart
Positioned(
  top: 90 * scale,
  left: ((designWidth - 500) / 2) * scale,
  child: Image.asset(
    'assets/citoyen_peyi/logo_citoyen_peyi_transparent.webp',
    width: 500 * scale,
    height: 120 * scale,
    fit: BoxFit.contain,
  ),
)
```

---

## 4. Fond de page

Fichier :

```text
assets/citoyen_peyi/home_background.webp
```

Dimensions de l’asset :

```text
1448 x 900 px
```

Le fond doit contenir uniquement :

- bleu profond à gauche ;
- bleu cyan à droite ;
- cercles translucides ;
- texture légère ;
- aucun texte ;
- aucun bouton ;
- aucun logo.

Couleurs de référence :

```text
Bleu foncé principal : #003F91
Bleu nuit : #002F7A
Bleu moyen : #005DA8
Bleu cyan : #0078B7
```

Flutter :

```dart
Positioned(
  top: 0,
  left: 0,
  right: 0,
  height: 900 * scale,
  child: Image.asset(
    'assets/citoyen_peyi/home_background.webp',
    fit: BoxFit.cover,
  ),
)
```

---

## 5. Pastille supérieure

Texte exact :

```text
Plateforme de consultation citoyenne anonyme
```

Position :

```text
Top : 222 px
Largeur : 535 px
Hauteur : 60 px
Alignement : centré
Rayon : 30 px
```

Style :

```text
Fond : rgba(255,255,255,0.07)
Bordure : rgba(255,255,255,0.22)
Texte : #FFFFFF
Police : Poppins
Taille : 22 px
Poids : 400
```

Code recommandé :

```dart
Positioned(
  top: 222 * scale,
  left: ((designWidth - 535) / 2) * scale,
  child: Container(
    width: 535 * scale,
    height: 60 * scale,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      color: Colors.white.withOpacity(0.07),
      borderRadius: BorderRadius.circular(30 * scale),
      border: Border.all(
        color: Colors.white.withOpacity(0.22),
        width: 1 * scale,
      ),
    ),
    child: Text(
      'Plateforme de consultation citoyenne anonyme',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontFamily: 'Poppins',
        fontSize: 22 * scale,
        fontWeight: FontWeight.w400,
        color: Colors.white,
      ),
    ),
  ),
)
```

---

## 6. Grand titre supprimé

Ne jamais afficher :

```text
Votez en toute confidentialité
```

Ce bloc doit rester totalement supprimé.

Il ne doit pas être remplacé par un autre titre.

Aucun paragraphe explicatif ne doit apparaître sous la pastille.

---

## 7. Encadré jaune institutionnel

Texte exact :

```text
Votre collectivité place votre parole au cœur
de l’action publique :
```

Position :

```text
Left : 315 px
Top : 352 px
Width : 790 px
Height : 154 px
Radius : 16 px
Bordure : 2 px
```

Étoile :

```text
Left : 288 px
Top : 337 px
Taille : 54 px
Couleur : #F4D000
```

Couleurs :

```text
Jaune : #F4D000
Blanc : #FFFFFF
```

Typographie :

```text
Police : Poppins
Taille : 31 px
Poids : 700
Hauteur de ligne : 1.35
Alignement : centre
```

RichText obligatoire :

- “Votre collectivité place ” en blanc ;
- “votre parole au cœur” en jaune ;
- retour ligne ;
- “de l’action publique” en jaune ;
- deux-points final discret.

Code recommandé :

```dart
Positioned(
  left: 288 * scale,
  top: 337 * scale,
  child: Icon(
    Icons.star,
    color: const Color(0xFFF4D000),
    size: 54 * scale,
  ),
),

Positioned(
  left: 315 * scale,
  top: 352 * scale,
  child: Container(
    width: 790 * scale,
    height: 154 * scale,
    alignment: Alignment.center,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16 * scale),
      border: Border.all(
        color: const Color(0xFFF4D000),
        width: 2 * scale,
      ),
    ),
    child: RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        style: TextStyle(
          fontFamily: 'Poppins',
          fontSize: 31 * scale,
          fontWeight: FontWeight.w700,
          height: 1.35,
          color: Colors.white,
        ),
        children: const [
          TextSpan(text: 'Votre collectivité place '),
          TextSpan(
            text: 'votre parole au cœur\n',
            style: TextStyle(color: Color(0xFFF4D000)),
          ),
          TextSpan(
            text: 'de l’action publique',
            style: TextStyle(color: Color(0xFFF4D000)),
          ),
          TextSpan(text: ' :'),
        ],
      ),
    ),
  ),
)
```

---

## 8. Boutons principaux

Les trois boutons existants restent sur une seule ligne.

Position générale :

```text
Top : 590 px
Height : 88 px
Espacement horizontal : environ 34 px
```

### 8.1 Bouton Administrateur communal

Texte :

```text
Administrateur communal
```

Position :

```text
Left : 230 px
Top : 590 px
Width : 330 px
Height : 88 px
Radius : 16 px
```

Style :

```text
Fond : #FFFFFF
Texte : #005098
Icône : #005098
Police : Poppins
Taille : 20 px
Poids : 700
```

Asset :

```text
assets/citoyen_peyi/icon_admin.webp
```

### 8.2 Bouton Contrôleur / accueil

Texte :

```text
Contrôleur / accueil
```

Position :

```text
Left : 594 px
Top : 590 px
Width : 288 px
Height : 88 px
Radius : 16 px
```

Style :

```text
Fond : transparent
Bordure : rgba(255,255,255,0.80)
Texte : #FFFFFF
Police : Poppins
Taille : 20 px
Poids : 600
```

Asset :

```text
assets/citoyen_peyi/icon_controller.webp
```

### 8.3 Bouton Je participe

Texte :

```text
Je participe
```

Position :

```text
Left : 914 px
Top : 590 px
Width : 268 px
Height : 88 px
Radius : 16 px
```

Style :

```text
Fond : transparent
Bordure : rgba(255,255,255,0.80)
Texte : #FFFFFF
Police : Poppins
Taille : 22 px
Poids : 700
```

Asset :

```text
assets/citoyen_peyi/icon_citizen.webp
```

---

## 9. Nouveau bouton Super administrateur

Ajouter un bouton supplémentaire sous la ligne des trois boutons.

Texte exact :

```text
Super administrateur
```

Position :

```text
Top : 710 px
Width : 360 px
Height : 78 px
Alignement : centré
Radius : 16 px
```

Style :

```text
Fond : rgba(255,255,255,0.06)
Bordure : #F4D000
Bordure : 2 px
Texte : #FFFFFF
Icône : #F4D000
Police : Poppins
Taille : 20 px
Poids : 700
```

Asset :

```text
assets/citoyen_peyi/icon_super_admin.webp
```

Le bouton ne doit pas voler la priorité visuelle au bouton “Je participe”.
Il doit rester premium, discret et institutionnel.

---

## 10. Barre de navigation basse

Position :

```text
Top : 900 px
Height : 186 px
Fond : #F7F7F9
```

La barre est fixe en bas.

Items :

```text
Accueil
Donner mon avis
Résultats
Actualités
Espace citoyen
```

Positions approximatives :

```text
Accueil : 136 px
Donner mon avis : 424 px
Résultats : 724 px
Actualités : 1010 px
Espace citoyen : 1262 px
```

Style item actif “Accueil” :

```text
Icône : #005098
Texte : #005098
Fond pastille : rgba(0,80,152,0.10)
Largeur pastille : 86 px
Hauteur pastille : 44 px
Rayon : 24 px
```

Style item inactif :

```text
Icône : #4A4A4A
Texte : #4A4A4A
Police : Poppins
Taille : 15 px
Poids : 600
```

Assets :

```text
assets/citoyen_peyi/nav_home.webp
assets/citoyen_peyi/nav_opinion.webp
assets/citoyen_peyi/nav_results.webp
assets/citoyen_peyi/nav_news.webp
assets/citoyen_peyi/nav_profile.webp
```

---

## 11. Structure Flutter obligatoire

Composant :

```text
CitoyenPeyiHomePage
```

Structure :

```dart
Scaffold(
  body: LayoutBuilder(
    builder: (context, constraints) {
      final scale = min(
        constraints.maxWidth / 1448,
        constraints.maxHeight / 1086,
      );

      return Center(
        child: SizedBox(
          width: 1448 * scale,
          height: 1086 * scale,
          child: Stack(
            children: [
              background,
              logo,
              topPill,
              yellowStatementBox,
              mainButtons,
              superAdminButton,
              bottomNavigation,
            ],
          ),
        ),
      );
    },
  ),
)
```

Interdictions Flutter :

- ne pas utiliser de scroll vertical sur tablette/web ;
- ne pas ajouter de `SingleChildScrollView` pour cette page ;
- ne pas utiliser de logo avec fond blanc ;
- ne pas réintroduire de titre principal ;
- ne pas ajouter de paragraphe explicatif.

---

## 12. Exemple de code pour bouton réutilisable

```dart
class CitizenHomeActionButton extends StatelessWidget {
  const CitizenHomeActionButton({
    super.key,
    required this.label,
    required this.iconPath,
    required this.width,
    required this.height,
    required this.backgroundColor,
    required this.borderColor,
    required this.textColor,
    required this.fontSize,
    this.borderWidth = 1,
    this.onPressed,
  });

  final String label;
  final String iconPath;
  final double width;
  final double height;
  final Color backgroundColor;
  final Color borderColor;
  final Color textColor;
  final double fontSize;
  final double borderWidth;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: Material(
        color: backgroundColor,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onPressed,
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: borderColor,
                width: borderWidth,
              ),
            ),
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  iconPath,
                  width: 30,
                  height: 30,
                  fit: BoxFit.contain,
                ),
                const SizedBox(width: 16),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontFamily: 'Poppins',
                      fontSize: fontSize,
                      fontWeight: FontWeight.w700,
                      color: textColor,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
```

---

## 13. Routes recommandées

Les boutons doivent pointer vers les routes suivantes :

```text
Administrateur communal : /admin-communal
Contrôleur / accueil : /controleur-accueil
Je participe : /participer
Super administrateur : /super-admin
Accueil : /accueil
Donner mon avis : /avis
Résultats : /resultats
Actualités : /actualites
Espace citoyen : /espace-citoyen
```

Si `go_router` est déjà utilisé, appeler :

```dart
context.go('/super-admin');
```

---

## 14. Checklist de validation

```text
[ ] Le logo n’a aucun fond blanc.
[ ] Le fichier logo est bien un .webp transparent.
[ ] Tous les assets image sont en .webp.
[ ] Le fond bleu ne contient ni texte, ni bouton.
[ ] La phrase “Votez en toute confidentialité” est absente.
[ ] Aucun paragraphe explicatif long n’est présent.
[ ] La pastille supérieure est centrée.
[ ] L’encadré jaune est remonté.
[ ] Le texte de l’encadré jaune est lisible au premier coup d’œil.
[ ] Les trois boutons principaux sont alignés.
[ ] Le bouton “Super administrateur” est ajouté sous les trois boutons.
[ ] La navigation basse reprend les 5 items.
[ ] La page tient sans scroll sur 1448 x 1086.
[ ] Le rendu final est institutionnel, propre et premium.
```

---

## 15. Prompt Copilot final à coller

```text
Crée la page Flutter CitoyenPeyiHomePage en pixel perfect sur une base 1448 x 1086.

Utilise uniquement les assets WebP présents dans assets/citoyen_peyi.

La page doit afficher :
1. Fond bleu home_background.webp de top 0 à 900 px.
2. Logo transparent logo_citoyen_peyi_transparent.webp centré en haut, top 90, width 500, height 120, sans carte blanche.
3. Pastille centrée top 222 avec le texte “Plateforme de consultation citoyenne anonyme”.
4. Aucun grand titre “Votez en toute confidentialité”.
5. Aucun paragraphe explicatif.
6. Encadré jaune top 352, left 315, width 790, height 154, border #F4D000 2 px, radius 16.
7. Étoile jaune top 337, left 288, size 54.
8. Texte RichText : “Votre collectivité place ” en blanc, “votre parole au cœur” en jaune, retour ligne, “de l’action publique” en jaune, “ :” discret.
9. Trois boutons top 590 :
   - Administrateur communal, x 230, width 330, fond blanc, texte #005098, icon_admin.webp.
   - Contrôleur / accueil, x 594, width 288, transparent, bordure blanche 80%, icon_controller.webp.
   - Je participe, x 914, width 268, transparent, bordure blanche 80%, icon_citizen.webp.
10. Ajouter sous ces boutons un bouton “Super administrateur”, top 710, centré, width 360, height 78, fond rgba(255,255,255,0.06), bordure #F4D000 2 px, texte blanc, icon_super_admin.webp.
11. Barre de navigation basse top 900, height 186, fond #F7F7F9.
12. Nav items : Accueil, Donner mon avis, Résultats, Actualités, Espace citoyen.
13. Accueil actif en bleu #005098 avec pastille rgba(0,80,152,0.10).
14. Items inactifs gris #4A4A4A.

Structure obligatoire :
Scaffold > LayoutBuilder > Center > SizedBox scaled 1448 x 1086 > Stack.

Ne pas ajouter de scroll, ne pas ajouter de texte explicatif, ne pas remettre “Votez en toute confidentialité”, ne pas mettre de fond blanc derrière le logo.
```
