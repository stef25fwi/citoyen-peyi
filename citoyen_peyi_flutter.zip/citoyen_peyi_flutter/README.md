# Citoyen Péyi Flutter

Conversion Flutter initiale de l'application web fournie dans l'archive source `vote-libre-main`.

## Ce qui est déjà migré

- architecture Flutter propre
- navigation avec `go_router`
- thème application
- modèles `Poll`, `RegistrationCode`, `CommuneConfig`, `ControllerCode`
- stockage local avec `SharedPreferences`
- écrans principaux :
  - accueil
  - login admin
  - login contrôleur
  - accès QR / code
  - vote
  - dashboard admin
  - création de sondage
  - inscriptions / codes
  - analytics
- graphiques de résultats
- génération de QR côté Flutter

## Ce qui reste à brancher pour une production complète

- Firebase Auth
- Firestore
- règles de sécurité
- scan caméra QR réel
- gestion avancée des rôles
- upload médias / assets de marque
- responsive desktop plus poussé

## Lancer

```bash
flutter pub get
flutter run
```

## Structure

- `lib/app/` : thème, routing, shell
- `lib/features/` : domaines fonctionnels
- `lib/shared/` : widgets, extensions, constantes
- `lib/services/` : persistance locale
- `lib/state/` : providers globaux

## Notes de migration

Le projet source n'était pas un projet Flutter mais une app React/Vite + TypeScript.  
Cette conversion reprend les flux métier principaux et les transforme en base Flutter maintenable.
