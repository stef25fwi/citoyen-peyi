import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../state/app_state.dart';

class AppScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  final List<Widget>? actions;
  final FloatingActionButton? floatingActionButton;
  final bool showBottomNav;

  const AppScaffold({
    super.key,
    required this.title,
    required this.child,
    this.actions,
    this.floatingActionButton,
    this.showBottomNav = false,
  });

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: actions,
      ),
      body: SafeArea(child: child),
      floatingActionButton: floatingActionButton,
      bottomNavigationBar: showBottomNav
          ? NavigationBar(
              selectedIndex: _selectedIndex(context),
              onDestinationSelected: (index) {
                if (index == 0) {
                  context.go('/');
                  return;
                }
                if (index == 1) {
                  context.go('/access');
                  return;
                }
                if (appState.isAdminLoggedIn) {
                  context.go('/admin');
                } else {
                  context.go('/admin/login');
                }
              },
              destinations: const [
                NavigationDestination(
                  icon: Icon(Icons.home_outlined),
                  selectedIcon: Icon(Icons.home),
                  label: 'Accueil',
                ),
                NavigationDestination(
                  icon: Icon(Icons.qr_code_2_outlined),
                  selectedIcon: Icon(Icons.qr_code_2),
                  label: 'Accès',
                ),
                NavigationDestination(
                  icon: Icon(Icons.admin_panel_settings_outlined),
                  selectedIcon: Icon(Icons.admin_panel_settings),
                  label: 'Admin',
                ),
              ],
            )
          : null,
    );
  }

  int _selectedIndex(BuildContext context) {
    final location = GoRouter.of(context).routeInformationProvider.value.uri.toString();
    if (location.startsWith('/access') || location.startsWith('/vote')) return 1;
    if (location.startsWith('/admin')) return 2;
    return 0;
  }
}
