import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../features/polls/domain/poll.dart';
import '../utils/date_formatters.dart';

class PollCard extends StatelessWidget {
  final Poll poll;

  const PollCard({
    super.key,
    required this.poll,
  });

  @override
  Widget build(BuildContext context) {
    final status = switch (poll.status) {
      PollStatus.active => ('En cours', const Color(0xFF0F9D58)),
      PollStatus.closed => ('Terminé', const Color(0xFFF4A100)),
      PollStatus.draft => ('Brouillon', const Color(0xFF0B6FA4)),
    };

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => context.go('/admin/inscriptions'),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  Chip(
                    label: Text(status.$1),
                    backgroundColor: status.$2.withOpacity(0.12),
                    labelStyle: TextStyle(
                      color: status.$2,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  Chip(
                    label: Text('${poll.totalVoted}/${poll.totalVoters} votants'),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                poll.projectTitle,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                poll.question,
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 12),
              Text(
                'Ouverture ${formatDate(poll.openDate)} • Clôture ${formatDate(poll.closeDate)}',
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: const Color(0xFF6E8090),
                    ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
