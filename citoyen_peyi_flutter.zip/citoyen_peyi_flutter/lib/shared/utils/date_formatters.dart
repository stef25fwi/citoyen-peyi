import 'package:intl/intl.dart';

final _frDate = DateFormat('dd/MM/yyyy', 'fr_FR');
final _frDateTime = DateFormat('dd/MM/yyyy HH:mm', 'fr_FR');

String formatDate(DateTime? date) {
  if (date == null) return '—';
  return _frDate.format(date);
}

String formatDateTime(DateTime? date) {
  if (date == null) return '—';
  return _frDateTime.format(date);
}
