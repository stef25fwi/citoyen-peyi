import 'dart:math';

import 'package:uuid/uuid.dart';

const _alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
final _random = Random.secure();
const _uuid = Uuid();

String randomId(String prefix) => '$prefix-${_uuid.v4()}';

String randomHumanCode({
  required String prefix,
  int length = 6,
}) {
  final buffer = StringBuffer(prefix);
  for (var i = 0; i < length; i++) {
    buffer.write(_alphabet[_random.nextInt(_alphabet.length)]);
  }
  return buffer.toString();
}
