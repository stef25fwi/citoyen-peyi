import 'dart:math';

import 'package:flutter/foundation.dart';

import '../features/controller/domain/controller_code.dart';
import '../features/polls/data/demo_polls.dart';
import '../features/polls/domain/poll.dart';
import '../features/registration/domain/registration_code.dart';
import '../services/local_storage_service.dart';
import '../shared/utils/id_generator.dart';

class AppState extends ChangeNotifier {
  AppState(this._storage);

  final LocalStorageService _storage;

  static const _adminSessionKey = 'admin_session_v1';
  static const _controllerSessionKey = 'controller_session_v1';
  static const _pollsKey = 'polls_v1';
  static const _registrationCodesKey = 'registration_codes_v1';
  static const _communeKey = 'admin_commune_v1';
  static const _controllerCodesKey = 'controller_codes_v1';

  bool _isAdminLoggedIn = false;
  ControllerSession? _controllerSession;
  List<Poll> _polls = [];
  List<RegistrationCode> _registrationCodes = [];
  CommuneConfig? _adminCommune;
  List<ControllerCode> _controllerCodes = [];

  bool get isAdminLoggedIn => _isAdminLoggedIn;
  bool get isControllerLoggedIn => _controllerSession != null;
  ControllerSession? get controllerSession => _controllerSession;
  List<Poll> get polls => List.unmodifiable(_polls);
  List<RegistrationCode> get registrationCodes => List.unmodifiable(_registrationCodes);
  CommuneConfig? get adminCommune => _adminCommune;
  List<ControllerCode> get controllerCodes => List.unmodifiable(_controllerCodes);

  Future<void> bootstrap() async {
    _isAdminLoggedIn = _storage.readString(_adminSessionKey) == '1';

    final sessionJson = _storage.readJson(_controllerSessionKey);
    if (sessionJson != null) {
      _controllerSession = ControllerSession.fromJson(sessionJson);
    }

    final pollsJson = _storage.readJsonList(_pollsKey);
    _polls = pollsJson.isEmpty
        ? List<Poll>.from(demoPolls)
        : pollsJson.map(Poll.fromJson).toList();

    final registrationsJson = _storage.readJsonList(_registrationCodesKey);
    _registrationCodes =
        registrationsJson.map(RegistrationCode.fromJson).toList();

    final communeJson = _storage.readJson(_communeKey);
    if (communeJson != null) {
      _adminCommune = CommuneConfig.fromJson(communeJson);
    }

    final controllersJson = _storage.readJsonList(_controllerCodesKey);
    _controllerCodes = controllersJson.map(ControllerCode.fromJson).toList();

    notifyListeners();
  }

  Future<void> loginAdmin({required String password}) async {
    if (password.trim() != 'admin123') {
      throw Exception('Mot de passe administrateur invalide.');
    }
    _isAdminLoggedIn = true;
    await _storage.writeString(_adminSessionKey, '1');
    notifyListeners();
  }

  Future<void> logoutAdmin() async {
    _isAdminLoggedIn = false;
    await _storage.remove(_adminSessionKey);
    notifyListeners();
  }

  Future<void> loginController(String code) async {
    final normalized = code.trim().toUpperCase();
    final match = _controllerCodes.where((e) => e.code == normalized).firstOrNull;
    if (match == null) {
      throw Exception('Code contrôleur invalide.');
    }

    final used = match.usedAt == null
        ? match.copyWith(usedAt: DateTime.now())
        : match;

    _controllerCodes = _controllerCodes
        .map((e) => e.id == used.id ? used : e)
        .toList();
    await _persistControllerCodes();

    _controllerSession = ControllerSession(
      id: used.id,
      code: used.code,
      label: used.label,
      commune: used.commune,
      connectedAt: DateTime.now(),
    );
    await _storage.writeJson(_controllerSessionKey, _controllerSession!.toJson());
    notifyListeners();
  }

  Future<void> logoutController() async {
    _controllerSession = null;
    await _storage.remove(_controllerSessionKey);
    notifyListeners();
  }

  Future<void> setAdminCommune(CommuneConfig commune) async {
    _adminCommune = commune;
    await _storage.writeJson(_communeKey, commune.toJson());
    notifyListeners();
  }

  Future<void> createPoll({
    required String projectTitle,
    required String question,
    required List<String> options,
    required DateTime openDate,
    required DateTime closeDate,
    required int totalVoters,
  }) async {
    final poll = Poll(
      id: randomId('poll'),
      projectTitle: projectTitle.trim(),
      question: question.trim(),
      options: options
          .where((e) => e.trim().isNotEmpty)
          .map(
            (e) => PollOption(
              id: randomId('opt'),
              label: e.trim(),
              votes: 0,
            ),
          )
          .toList(),
      openDate: openDate,
      closeDate: closeDate,
      status: deriveStatus(openDate, closeDate),
      totalVoters: totalVoters,
      totalVoted: 0,
    );

    _polls = [poll, ..._polls];
    await _persistPolls();
    notifyListeners();
  }

  Future<void> recordVote({
    required String token,
    required String optionId,
  }) async {
    final registration = _registrationCodes.where((e) => e.code == token).firstOrNull;
    if (registration == null) {
      throw Exception('Code inconnu.');
    }
    if (registration.votedAt != null) {
      throw Exception('Ce code a déjà été utilisé pour voter.');
    }

    final pollIndex = _polls.indexWhere((e) => e.id == registration.pollId);
    if (pollIndex < 0) {
      throw Exception('Sondage introuvable.');
    }

    final poll = _polls[pollIndex];
    final updatedPoll = poll.copyWith(
      totalVoted: min(poll.totalVoted + 1, poll.totalVoters == 0 ? poll.totalVoted + 1 : poll.totalVoters),
      options: poll.options
          .map(
            (e) => e.id == optionId ? e.copyWith(votes: e.votes + 1) : e,
          )
          .toList(),
    );

    _polls[pollIndex] = updatedPoll;
    _registrationCodes = _registrationCodes
        .map(
          (e) => e.id == registration.id
              ? e.copyWith(votedAt: DateTime.now(), status: RegistrationCodeStatus.validated)
              : e,
        )
        .toList();

    await _persistPolls();
    await _persistRegistrationCodes();
    notifyListeners();
  }

  Future<void> generateRegistrationCodes({
    required String pollId,
    required int count,
  }) async {
    final communeName = _adminCommune?.name;
    final now = DateTime.now();

    final generated = List.generate(count, (index) {
      final code = randomHumanCode(prefix: 'INS-', length: 6);
      return RegistrationCode(
        id: randomId('reg'),
        code: code,
        pollId: pollId,
        createdAt: now,
        usedBy: null,
        status: RegistrationCodeStatus.available,
        documentType: null,
        validatedAt: null,
        expiresAt: DateTime(now.year + 2, now.month, now.day),
        communeName: communeName,
        qrPayload: code,
        activatedAt: null,
        votedAt: null,
        verifiedByControllerCode: null,
        verifiedByControllerLabel: null,
      );
    });

    _registrationCodes = [...generated, ..._registrationCodes];
    await _persistRegistrationCodes();
    notifyListeners();
  }

  Future<void> markCodeValidated({
    required String code,
    String? documentType,
  }) async {
    final normalized = code.trim().toUpperCase();
    final controller = _controllerSession;
    if (controller == null) {
      throw Exception('Aucun contrôleur connecté.');
    }

    final match = _registrationCodes.where((e) => e.code == normalized).firstOrNull;
    if (match == null) {
      throw Exception('Code introuvable.');
    }

    _registrationCodes = _registrationCodes
        .map(
          (e) => e.id == match.id
              ? e.copyWith(
                  status: RegistrationCodeStatus.validated,
                  validatedAt: DateTime.now(),
                  activatedAt: DateTime.now(),
                  documentType: documentType,
                  verifiedByControllerCode: controller.code,
                  verifiedByControllerLabel: controller.label,
                )
              : e,
        )
        .toList();

    await _persistRegistrationCodes();
    notifyListeners();
  }

  Future<void> createControllerCode(String label) async {
    final commune = _adminCommune;
    if (commune == null) {
      throw Exception('Rattache d’abord une commune au compte admin.');
    }

    final controllerCode = ControllerCode(
      id: randomId('ctrl'),
      code: randomHumanCode(prefix: 'CTRL-', length: 8),
      label: label.trim().isEmpty ? 'Contrôleur' : label.trim(),
      commune: commune,
      createdAt: DateTime.now(),
      usedAt: null,
    );
    _controllerCodes = [controllerCode, ..._controllerCodes];
    await _persistControllerCodes();
    notifyListeners();
  }

  Poll? findPoll(String id) {
    try {
      return _polls.firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }

  Poll? findPollByToken(String token) {
    try {
      final reg = _registrationCodes.firstWhere((e) => e.code == token);
      return findPoll(reg.pollId);
    } catch (_) {
      return null;
    }
  }

  RegistrationCode? findRegistrationByToken(String token) {
    try {
      return _registrationCodes.firstWhere((e) => e.code == token);
    } catch (_) {
      return null;
    }
  }

  Future<void> _persistPolls() async {
    await _storage.writeJsonList(
      _pollsKey,
      _polls.map((e) => e.toJson()).toList(),
    );
  }

  Future<void> _persistRegistrationCodes() async {
    await _storage.writeJsonList(
      _registrationCodesKey,
      _registrationCodes.map((e) => e.toJson()).toList(),
    );
  }

  Future<void> _persistControllerCodes() async {
    await _storage.writeJsonList(
      _controllerCodesKey,
      _controllerCodes.map((e) => e.toJson()).toList(),
    );
  }
}

PollStatus deriveStatus(DateTime openDate, DateTime closeDate) {
  final today = DateTime.now();
  final onlyToday = DateTime(today.year, today.month, today.day);
  final onlyOpen = DateTime(openDate.year, openDate.month, openDate.day);
  final onlyClose = DateTime(closeDate.year, closeDate.month, closeDate.day);

  if (onlyClose.isBefore(onlyToday)) return PollStatus.closed;
  if (onlyOpen.isAfter(onlyToday)) return PollStatus.draft;
  return PollStatus.active;
}

extension FirstWhereOrNullExtension<E> on Iterable<E> {
  E? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}
