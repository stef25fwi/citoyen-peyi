import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../features/admin/presentation/admin_analytics_page.dart';
import '../features/admin/presentation/admin_create_poll_page.dart';
import '../features/admin/presentation/admin_dashboard_page.dart';
import '../features/admin/presentation/admin_login_page.dart';
import '../features/admin/presentation/admin_registrations_page.dart';
import '../features/auth/presentation/controller_login_page.dart';
import '../features/home/presentation/home_page.dart';
import '../features/vote/presentation/qr_access_page.dart';
import '../features/vote/presentation/vote_page.dart';
import '../state/app_state.dart';

GoRouter buildRouter(AppState appState) {
  return GoRouter(
    initialLocation: '/',
    refreshListenable: appState,
    redirect: (context, state) {
      final path = state.fullPath ?? state.uri.toString();
      final needsAdmin = path.startsWith('/admin') &&
          path != '/admin/login';
      final needsController = path == '/admin/inscriptions';

      if (needsAdmin && !appState.isAdminLoggedIn) {
        return '/admin/login';
      }

      if (needsController &&
          !appState.isAdminLoggedIn &&
          !appState.isControllerLoggedIn) {
        return '/controleur/login';
      }

      return null;
    },
    routes: [
      GoRoute(
        path: '/',
        builder: (_, __) => const HomePage(),
      ),
      GoRoute(
        path: '/admin/login',
        builder: (_, __) => const AdminLoginPage(),
      ),
      GoRoute(
        path: '/admin',
        builder: (_, __) => const AdminDashboardPage(),
      ),
      GoRoute(
        path: '/admin/create',
        builder: (_, __) => const AdminCreatePollPage(),
      ),
      GoRoute(
        path: '/admin/analytics',
        builder: (_, __) => const AdminAnalyticsPage(),
      ),
      GoRoute(
        path: '/admin/inscriptions',
        builder: (_, __) => const AdminRegistrationsPage(),
      ),
      GoRoute(
        path: '/controleur/login',
        builder: (_, __) => const ControllerLoginPage(),
      ),
      GoRoute(
        path: '/access',
        builder: (_, __) => const QrAccessPage(),
      ),
      GoRoute(
        path: '/vote/:token',
        builder: (_, state) => VotePage(
          token: state.pathParameters['token'] ?? '',
        ),
      ),
    ],
    errorBuilder: (_, __) => const Scaffold(
      body: Center(
        child: Text('Page introuvable'),
      ),
    ),
  );
}
