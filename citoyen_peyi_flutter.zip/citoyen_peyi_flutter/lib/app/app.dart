import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../state/app_state.dart';
import 'router.dart';
import 'theme.dart';

class CitoyenPeyiApp extends StatelessWidget {
  const CitoyenPeyiApp({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = context.watch<AppState>();

    return MaterialApp.router(
      title: 'Citoyen Péyi',
      debugShowCheckedModeBanner: false,
      theme: buildAppTheme(),
      routerConfig: buildRouter(appState),
    );
  }
}
