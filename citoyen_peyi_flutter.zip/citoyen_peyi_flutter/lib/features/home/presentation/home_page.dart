import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../shared/widgets/app_scaffold.dart';
import '../../../shared/widgets/section_title.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  static const _features = [
    (
      icon: Icons.how_to_vote_outlined,
      title: 'Vote simple',
      desc: 'Interface intuitive pour voter en quelques secondes.'
    ),
    (
      icon: Icons.shield_outlined,
      title: 'Anonymat garanti',
      desc: 'Architecture séparant identité et bulletin de vote.'
    ),
    (
      icon: Icons.qr_code_2_outlined,
      title: 'Accès par QR code',
      desc: 'Chaque participant reçoit un QR code unique et personnel.'
    ),
    (
      icon: Icons.bar_chart_outlined,
      title: 'Résultats en temps réel',
      desc: 'Tableau de bord avec résultats agrégés et taux de participation.'
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Citoyen Péyi',
      showBottomNav: true,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(
                colors: [Color(0xFF0B6FA4), Color(0xFF12B3C7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Chip(
                  label: Text('Plateforme de sondage anonyme'),
                  backgroundColor: Colors.white24,
                  labelStyle: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 18),
                Text(
                  'Votez en toute confidentialité',
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 12),
                Text(
                  'Votre collectivité place votre parole au cœur de l’action publique grâce à une solution moderne, anonyme et transparente.',
                  style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                        color: Colors.white.withOpacity(0.92),
                      ),
                ),
                const SizedBox(height: 20),
                FilledButton.icon(
                  onPressed: () => context.go('/admin/login'),
                  icon: const Icon(Icons.admin_panel_settings_outlined),
                  label: const Text('Espace admin'),
                  style: FilledButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: const Color(0xFF0B6FA4),
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => context.go('/controleur/login'),
                      icon: const Icon(Icons.badge_outlined),
                      label: const Text('Contrôleur'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white38),
                      ),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => context.go('/access'),
                      icon: const Icon(Icons.qr_code_2),
                      label: const Text('Accéder avec un code'),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white,
                        side: const BorderSide(color: Colors.white38),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 28),
          const SectionTitle(
            title: 'Comment ça fonctionne ?',
            subtitle: 'Un processus simple, sécurisé et entièrement anonyme.',
          ),
          const SizedBox(height: 16),
          ..._features.map(
            (feature) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(
                child: ListTile(
                  contentPadding: const EdgeInsets.all(16),
                  leading: CircleAvatar(
                    radius: 24,
                    backgroundColor: const Color(0xFF0B6FA4).withOpacity(0.12),
                    child: Icon(feature.icon, color: const Color(0xFF0B6FA4)),
                  ),
                  title: Text(
                    feature.title,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  subtitle: Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(feature.desc),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
