class CommuneConfig {
  final String name;
  final String? code;
  final String? postalCode;
  final int population;
  final int maxCodes;

  const CommuneConfig({
    required this.name,
    this.code,
    this.postalCode,
    required this.population,
    required this.maxCodes,
  });

  Map<String, dynamic> toJson() => {
        'name': name,
        'code': code,
        'postalCode': postalCode,
        'population': population,
        'maxCodes': maxCodes,
      };

  factory CommuneConfig.fromJson(Map<String, dynamic> json) {
    return CommuneConfig(
      name: json['name'] as String? ?? '',
      code: json['code'] as String?,
      postalCode: json['postalCode'] as String?,
      population: json['population'] as int? ?? 0,
      maxCodes: json['maxCodes'] as int? ?? 0,
    );
  }
}

enum RegistrationCodeStatus { available, assigned, validated }

class RegistrationCode {
  final String id;
  final String code;
  final String pollId;
  final DateTime createdAt;
  final String? usedBy;
  final RegistrationCodeStatus status;
  final String? documentType;
  final DateTime? validatedAt;
  final DateTime? expiresAt;
  final String? communeName;
  final String? qrPayload;
  final DateTime? activatedAt;
  final DateTime? votedAt;
  final String? verifiedByControllerCode;
  final String? verifiedByControllerLabel;

  const RegistrationCode({
    required this.id,
    required this.code,
    required this.pollId,
    required this.createdAt,
    required this.usedBy,
    required this.status,
    required this.documentType,
    required this.validatedAt,
    required this.expiresAt,
    required this.communeName,
    required this.qrPayload,
    required this.activatedAt,
    required this.votedAt,
    required this.verifiedByControllerCode,
    required this.verifiedByControllerLabel,
  });

  RegistrationCode copyWith({
    String? id,
    String? code,
    String? pollId,
    DateTime? createdAt,
    Object? usedBy = _sentinel,
    RegistrationCodeStatus? status,
    Object? documentType = _sentinel,
    Object? validatedAt = _sentinel,
    Object? expiresAt = _sentinel,
    Object? communeName = _sentinel,
    Object? qrPayload = _sentinel,
    Object? activatedAt = _sentinel,
    Object? votedAt = _sentinel,
    Object? verifiedByControllerCode = _sentinel,
    Object? verifiedByControllerLabel = _sentinel,
  }) {
    return RegistrationCode(
      id: id ?? this.id,
      code: code ?? this.code,
      pollId: pollId ?? this.pollId,
      createdAt: createdAt ?? this.createdAt,
      usedBy: usedBy == _sentinel ? this.usedBy : usedBy as String?,
      status: status ?? this.status,
      documentType: documentType == _sentinel ? this.documentType : documentType as String?,
      validatedAt: validatedAt == _sentinel ? this.validatedAt : validatedAt as DateTime?,
      expiresAt: expiresAt == _sentinel ? this.expiresAt : expiresAt as DateTime?,
      communeName: communeName == _sentinel ? this.communeName : communeName as String?,
      qrPayload: qrPayload == _sentinel ? this.qrPayload : qrPayload as String?,
      activatedAt: activatedAt == _sentinel ? this.activatedAt : activatedAt as DateTime?,
      votedAt: votedAt == _sentinel ? this.votedAt : votedAt as DateTime?,
      verifiedByControllerCode: verifiedByControllerCode == _sentinel
          ? this.verifiedByControllerCode
          : verifiedByControllerCode as String?,
      verifiedByControllerLabel: verifiedByControllerLabel == _sentinel
          ? this.verifiedByControllerLabel
          : verifiedByControllerLabel as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'pollId': pollId,
        'createdAt': createdAt.toIso8601String(),
        'usedBy': usedBy,
        'status': status.name,
        'documentType': documentType,
        'validatedAt': validatedAt?.toIso8601String(),
        'expiresAt': expiresAt?.toIso8601String(),
        'communeName': communeName,
        'qrPayload': qrPayload,
        'activatedAt': activatedAt?.toIso8601String(),
        'votedAt': votedAt?.toIso8601String(),
        'verifiedByControllerCode': verifiedByControllerCode,
        'verifiedByControllerLabel': verifiedByControllerLabel,
      };

  factory RegistrationCode.fromJson(Map<String, dynamic> json) {
    return RegistrationCode(
      id: json['id'] as String? ?? '',
      code: json['code'] as String? ?? '',
      pollId: json['pollId'] as String? ?? '',
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      usedBy: json['usedBy'] as String?,
      status: RegistrationCodeStatus.values.byName(json['status'] as String? ?? 'available'),
      documentType: json['documentType'] as String?,
      validatedAt: DateTime.tryParse(json['validatedAt'] as String? ?? ''),
      expiresAt: DateTime.tryParse(json['expiresAt'] as String? ?? ''),
      communeName: json['communeName'] as String?,
      qrPayload: json['qrPayload'] as String?,
      activatedAt: DateTime.tryParse(json['activatedAt'] as String? ?? ''),
      votedAt: DateTime.tryParse(json['votedAt'] as String? ?? ''),
      verifiedByControllerCode: json['verifiedByControllerCode'] as String?,
      verifiedByControllerLabel: json['verifiedByControllerLabel'] as String?,
    );
  }
}

const _sentinel = Object();
