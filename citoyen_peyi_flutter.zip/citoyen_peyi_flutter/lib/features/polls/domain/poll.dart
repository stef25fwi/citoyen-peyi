enum PollStatus { draft, active, closed }

class PollOption {
  final String id;
  final String label;
  final int votes;

  const PollOption({
    required this.id,
    required this.label,
    required this.votes,
  });

  PollOption copyWith({
    String? id,
    String? label,
    int? votes,
  }) {
    return PollOption(
      id: id ?? this.id,
      label: label ?? this.label,
      votes: votes ?? this.votes,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'votes': votes,
      };

  factory PollOption.fromJson(Map<String, dynamic> json) {
    return PollOption(
      id: json['id'] as String? ?? '',
      label: json['label'] as String? ?? '',
      votes: json['votes'] as int? ?? 0,
    );
  }
}

class Poll {
  final String id;
  final String projectTitle;
  final String question;
  final List<PollOption> options;
  final DateTime openDate;
  final DateTime closeDate;
  final PollStatus status;
  final int totalVoters;
  final int totalVoted;

  const Poll({
    required this.id,
    required this.projectTitle,
    required this.question,
    required this.options,
    required this.openDate,
    required this.closeDate,
    required this.status,
    required this.totalVoters,
    required this.totalVoted,
  });

  Poll copyWith({
    String? id,
    String? projectTitle,
    String? question,
    List<PollOption>? options,
    DateTime? openDate,
    DateTime? closeDate,
    PollStatus? status,
    int? totalVoters,
    int? totalVoted,
  }) {
    return Poll(
      id: id ?? this.id,
      projectTitle: projectTitle ?? this.projectTitle,
      question: question ?? this.question,
      options: options ?? this.options,
      openDate: openDate ?? this.openDate,
      closeDate: closeDate ?? this.closeDate,
      status: status ?? this.status,
      totalVoters: totalVoters ?? this.totalVoters,
      totalVoted: totalVoted ?? this.totalVoted,
    );
  }

  double get participationRate {
    if (totalVoters <= 0) return 0;
    return totalVoted / totalVoters;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'projectTitle': projectTitle,
        'question': question,
        'options': options.map((e) => e.toJson()).toList(),
        'openDate': openDate.toIso8601String(),
        'closeDate': closeDate.toIso8601String(),
        'status': status.name,
        'totalVoters': totalVoters,
        'totalVoted': totalVoted,
      };

  factory Poll.fromJson(Map<String, dynamic> json) {
    return Poll(
      id: json['id'] as String? ?? '',
      projectTitle: json['projectTitle'] as String? ?? '',
      question: json['question'] as String? ?? '',
      options: (json['options'] as List<dynamic>? ?? [])
          .map((e) => PollOption.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      openDate: DateTime.tryParse(json['openDate'] as String? ?? '') ?? DateTime.now(),
      closeDate: DateTime.tryParse(json['closeDate'] as String? ?? '') ?? DateTime.now(),
      status: PollStatus.values.byName(json['status'] as String? ?? 'draft'),
      totalVoters: json['totalVoters'] as int? ?? 0,
      totalVoted: json['totalVoted'] as int? ?? 0,
    );
  }
}
