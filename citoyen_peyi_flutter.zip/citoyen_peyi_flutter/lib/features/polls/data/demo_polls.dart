import '../domain/poll.dart';

final demoPolls = <Poll>[
  Poll(
    id: 'poll-1',
    projectTitle: 'Réaménagement de la place centrale',
    question: 'Quelle option préférez-vous pour le réaménagement de la place centrale ?',
    options: const [
      PollOption(id: 'opt-1', label: 'Espace vert avec aires de jeux', votes: 47),
      PollOption(id: 'opt-2', label: 'Marché couvert et terrasses', votes: 32),
      PollOption(id: 'opt-3', label: 'Parking souterrain et esplanade piétonne', votes: 28),
      PollOption(id: 'opt-4', label: 'Zone mixte commerces et espaces verts', votes: 53),
    ],
    openDate: DateTime(2026, 3, 15),
    closeDate: DateTime(2026, 6, 15),
    status: PollStatus.active,
    totalVoters: 200,
    totalVoted: 160,
  ),
  Poll(
    id: 'poll-2',
    projectTitle: 'Nouvelle médiathèque municipale',
    question: 'Quel nom souhaitez-vous donner à la nouvelle médiathèque ?',
    options: const [
      PollOption(id: 'opt-5', label: 'Médiathèque Simone Veil', votes: 64),
      PollOption(id: 'opt-6', label: 'Médiathèque des Lumières', votes: 41),
      PollOption(id: 'opt-7', label: 'Médiathèque du Lac', votes: 35),
    ],
    openDate: DateTime(2026, 2, 1),
    closeDate: DateTime(2026, 3, 1),
    status: PollStatus.closed,
    totalVoters: 180,
    totalVoted: 140,
  ),
  Poll(
    id: 'poll-3',
    projectTitle: 'Festival d’été 2026',
    question: 'Quel thème pour le festival d’été 2026 ?',
    options: const [
      PollOption(id: 'opt-8', label: 'Musiques du monde', votes: 0),
      PollOption(id: 'opt-9', label: 'Cinéma en plein air', votes: 0),
      PollOption(id: 'opt-10', label: 'Arts de rue et cirque', votes: 0),
      PollOption(id: 'opt-11', label: 'Gastronomie locale', votes: 0),
    ],
    openDate: DateTime(2026, 4, 1),
    closeDate: DateTime(2026, 5, 1),
    status: PollStatus.draft,
    totalVoters: 0,
    totalVoted: 0,
  ),
];
