import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../shared/widgets/app_scaffold.dart';
import '../../../state/app_state.dart';

class ControllerLoginPage extends StatefulWidget {
  const ControllerLoginPage({super.key});

  @override
  State<ControllerLoginPage> createState() => _ControllerLoginPageState();
}

class _ControllerLoginPageState extends State<ControllerLoginPage> {
  final _controller = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _submit() async {
    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      await context.read<AppState>().loginController(_controller.text);
      if (!mounted) return;
      context.go('/admin/inscriptions');
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Connexion contrôleur',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.badge_outlined, size: 56, color: Color(0xFF0B6FA4)),
                  const SizedBox(height: 16),
                  Text(
                    'Code contrôleur',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _controller,
                    decoration: InputDecoration(
                      labelText: 'Ex. CTRL-ABCDEFGH',
                      errorText: _error,
                    ),
                    textCapitalization: TextCapitalization.characters,
                    onSubmitted: (_) => _submit(),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _loading ? null : _submit,
                    child: Text(_loading ? 'Connexion...' : 'Valider'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
