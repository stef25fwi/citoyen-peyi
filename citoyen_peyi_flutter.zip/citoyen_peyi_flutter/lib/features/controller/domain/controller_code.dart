import '../../registration/domain/registration_code.dart';

class ControllerCode {
  final String id;
  final String code;
  final String label;
  final CommuneConfig? commune;
  final DateTime createdAt;
  final DateTime? usedAt;

  const ControllerCode({
    required this.id,
    required this.code,
    required this.label,
    required this.commune,
    required this.createdAt,
    required this.usedAt,
  });

  ControllerCode copyWith({
    String? id,
    String? code,
    String? label,
    Object? commune = _sentinel,
    DateTime? createdAt,
    Object? usedAt = _sentinel,
  }) {
    return ControllerCode(
      id: id ?? this.id,
      code: code ?? this.code,
      label: label ?? this.label,
      commune: commune == _sentinel ? this.commune : commune as CommuneConfig?,
      createdAt: createdAt ?? this.createdAt,
      usedAt: usedAt == _sentinel ? this.usedAt : usedAt as DateTime?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'label': label,
        'commune': commune?.toJson(),
        'createdAt': createdAt.toIso8601String(),
        'usedAt': usedAt?.toIso8601String(),
      };

  factory ControllerCode.fromJson(Map<String, dynamic> json) {
    return ControllerCode(
      id: json['id'] as String? ?? '',
      code: json['code'] as String? ?? '',
      label: json['label'] as String? ?? '',
      commune: json['commune'] == null
          ? null
          : CommuneConfig.fromJson(Map<String, dynamic>.from(json['commune'] as Map)),
      createdAt: DateTime.tryParse(json['createdAt'] as String? ?? '') ?? DateTime.now(),
      usedAt: DateTime.tryParse(json['usedAt'] as String? ?? ''),
    );
  }
}

class ControllerSession {
  final String id;
  final String code;
  final String label;
  final CommuneConfig? commune;
  final DateTime connectedAt;

  const ControllerSession({
    required this.id,
    required this.code,
    required this.label,
    required this.commune,
    required this.connectedAt,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'code': code,
        'label': label,
        'commune': commune?.toJson(),
        'connectedAt': connectedAt.toIso8601String(),
      };

  factory ControllerSession.fromJson(Map<String, dynamic> json) {
    return ControllerSession(
      id: json['id'] as String? ?? '',
      code: json['code'] as String? ?? '',
      label: json['label'] as String? ?? '',
      commune: json['commune'] == null
          ? null
          : CommuneConfig.fromJson(Map<String, dynamic>.from(json['commune'] as Map)),
      connectedAt: DateTime.tryParse(json['connectedAt'] as String? ?? '') ?? DateTime.now(),
    );
  }
}

const _sentinel = Object();
