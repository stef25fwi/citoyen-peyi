import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../app/theme.dart';
import '../../../features/polls/domain/poll.dart';
import '../../../features/registration/domain/registration_code.dart';
import '../../../shared/widgets/app_scaffold.dart';
import '../../../shared/widgets/poll_card.dart';
import '../../../shared/widgets/section_title.dart';
import '../../../shared/widgets/stat_card.dart';
import '../../../state/app_state.dart';

class AdminDashboardPage extends StatelessWidget {
  const AdminDashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final colors = Theme.of(context).extension<AppColors>()!;
    final polls = state.polls;
    final active = polls.where((e) => e.status == PollStatus.active).toList();
    final closed = polls.where((e) => e.status == PollStatus.closed).toList();
    final drafts = polls.where((e) => e.status == PollStatus.draft).toList();

    return AppScaffold(
      title: 'Tableau de bord',
      showBottomNav: true,
      actions: [
        IconButton(
          tooltip: 'Analytics',
          onPressed: () => context.go('/admin/analytics'),
          icon: const Icon(Icons.auto_graph_outlined),
        ),
        IconButton(
          tooltip: 'Déconnexion',
          onPressed: () async {
            await state.logoutAdmin();
            if (context.mounted) context.go('/');
          },
          icon: const Icon(Icons.logout),
        ),
      ],
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.go('/admin/create'),
        icon: const Icon(Icons.add),
        label: const Text('Nouveau'),
      ),
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionTitle(
                    title: 'Profil administrateur',
                    subtitle: 'Collectivité de rattachement du compte.',
                  ),
                  const SizedBox(height: 12),
                  if (state.adminCommune != null)
                    Wrap(
                      spacing: 10,
                      runSpacing: 10,
                      children: [
                        Chip(
                          avatar: const Icon(Icons.location_city, size: 18),
                          label: Text(state.adminCommune!.name),
                        ),
                        Chip(
                          label: Text('${state.adminCommune!.population} habitants'),
                        ),
                      ],
                    )
                  else
                    const Text('Aucune commune définie.'),
                  const SizedBox(height: 16),
                  OutlinedButton.icon(
                    onPressed: () => _openCommuneDialog(context),
                    icon: const Icon(Icons.edit_location_alt_outlined),
                    label: Text(state.adminCommune == null
                        ? 'Choisir une commune'
                        : 'Changer de commune'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          GridView.count(
            crossAxisCount: MediaQuery.sizeOf(context).width > 900 ? 4 : 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.7,
            children: [
              StatCard(label: 'Total sondages', value: '${polls.length}', icon: Icons.ballot_outlined, color: Theme.of(context).colorScheme.primary),
              StatCard(label: 'En cours', value: '${active.length}', icon: Icons.play_circle_outline, color: colors.success),
              StatCard(label: 'Terminés', value: '${closed.length}', icon: Icons.check_circle_outline, color: colors.warning),
              StatCard(label: 'Brouillons', value: '${drafts.length}', icon: Icons.edit_note_outlined, color: Theme.of(context).colorScheme.secondary),
            ],
          ),
          const SizedBox(height: 24),
          if (active.isNotEmpty) ...[
            const SectionTitle(title: 'Sondages en cours'),
            const SizedBox(height: 12),
            ...active.map((poll) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: PollCard(poll: poll),
                )),
            const SizedBox(height: 12),
          ],
          if (closed.isNotEmpty) ...[
            const SectionTitle(title: 'Terminés'),
            const SizedBox(height: 12),
            ...closed.map((poll) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: PollCard(poll: poll),
                )),
            const SizedBox(height: 12),
          ],
          if (drafts.isNotEmpty) ...[
            const SectionTitle(title: 'Brouillons'),
            const SizedBox(height: 12),
            ...drafts.map((poll) => Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: PollCard(poll: poll),
                )),
          ],
          const SizedBox(height: 24),
          const SectionTitle(
            title: 'Accès contrôleurs',
            subtitle: 'Créer et distribuer des codes aux agents de contrôle.',
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          '${state.controllerCodes.length} code(s) contrôleur',
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                        ),
                      ),
                      FilledButton.icon(
                        onPressed: () => _openControllerDialog(context),
                        icon: const Icon(Icons.add_moderator_outlined),
                        label: const Text('Créer'),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (state.controllerCodes.isEmpty)
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Aucun code contrôleur créé pour le moment.'),
                    )
                  else
                    ...state.controllerCodes.map(
                      (item) => ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: const CircleAvatar(child: Icon(Icons.badge_outlined)),
                        title: Text(item.label),
                        subtitle: Text(item.code),
                        trailing: Text(item.usedAt == null ? 'Jamais utilisé' : 'Utilisé'),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _openCommuneDialog(BuildContext context) async {
    final name = TextEditingController();
    final postal = TextEditingController();
    final population = TextEditingController(text: '30000');

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Rattacher une commune'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom de la commune')),
            const SizedBox(height: 12),
            TextField(controller: postal, decoration: const InputDecoration(labelText: 'Code postal')),
            const SizedBox(height: 12),
            TextField(
              controller: population,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Population'),
            ),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
          FilledButton(
            onPressed: () async {
              final commune = CommuneConfig(
                name: name.text.trim().isEmpty ? 'Commune pilote' : name.text.trim(),
                postalCode: postal.text.trim().isEmpty ? null : postal.text.trim(),
                population: int.tryParse(population.text) ?? 0,
                maxCodes: int.tryParse(population.text) ?? 0,
              );
              await context.read<AppState>().setAdminCommune(commune);
              if (context.mounted) Navigator.pop(context);
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
  }

  Future<void> _openControllerDialog(BuildContext context) async {
    final label = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Créer un code contrôleur'),
        content: TextField(
          controller: label,
          decoration: const InputDecoration(labelText: 'Libellé'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
          FilledButton(
            onPressed: () async {
              try {
                await context.read<AppState>().createControllerCode(label.text);
                if (context.mounted) Navigator.pop(context);
              } catch (e) {
                if (!context.mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
                );
              }
            },
            child: const Text('Créer'),
          ),
        ],
      ),
    );
  }
}
