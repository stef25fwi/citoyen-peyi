import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import '../../../shared/widgets/app_scaffold.dart';
import '../../../state/app_state.dart';

class AdminCreatePollPage extends StatefulWidget {
  const AdminCreatePollPage({super.key});

  @override
  State<AdminCreatePollPage> createState() => _AdminCreatePollPageState();
}

class _AdminCreatePollPageState extends State<AdminCreatePollPage> {
  final _formKey = GlobalKey<FormState>();
  final _projectController = TextEditingController();
  final _questionController = TextEditingController();
  final _votersController = TextEditingController(text: '200');
  final _optionControllers = List.generate(4, (_) => TextEditingController());
  DateTime _openDate = DateTime.now();
  DateTime _closeDate = DateTime.now().add(const Duration(days: 30));
  bool _loading = false;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    await context.read<AppState>().createPoll(
          projectTitle: _projectController.text,
          question: _questionController.text,
          options: _optionControllers.map((e) => e.text).toList(),
          openDate: _openDate,
          closeDate: _closeDate,
          totalVoters: int.tryParse(_votersController.text) ?? 0,
        );
    if (!mounted) return;
    context.go('/admin');
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Créer un sondage',
      child: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Column(
                  children: [
                    TextFormField(
                      controller: _projectController,
                      decoration: const InputDecoration(labelText: 'Titre du projet'),
                      validator: (value) => (value == null || value.trim().isEmpty) ? 'Champ requis' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: _questionController,
                      maxLines: 3,
                      decoration: const InputDecoration(labelText: 'Question'),
                      validator: (value) => (value == null || value.trim().isEmpty) ? 'Champ requis' : null,
                    ),
                    const SizedBox(height: 12),
                    ...List.generate(
                      _optionControllers.length,
                      (index) => Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: TextFormField(
                          controller: _optionControllers[index],
                          decoration: InputDecoration(labelText: 'Option ${index + 1}'),
                          validator: index < 2
                              ? (value) => (value == null || value.trim().isEmpty) ? 'Au moins 2 options' : null
                              : null,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    TextFormField(
                      controller: _votersController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Nombre d’électeurs attendus'),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Ouverture'),
                            subtitle: Text('${_openDate.day}/${_openDate.month}/${_openDate.year}'),
                            onTap: () async {
                              final date = await showDatePicker(
                                context: context,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2030),
                                initialDate: _openDate,
                              );
                              if (date != null) setState(() => _openDate = date);
                            },
                          ),
                        ),
                        Expanded(
                          child: ListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Clôture'),
                            subtitle: Text('${_closeDate.day}/${_closeDate.month}/${_closeDate.year}'),
                            onTap: () async {
                              final date = await showDatePicker(
                                context: context,
                                firstDate: DateTime(2020),
                                lastDate: DateTime(2030),
                                initialDate: _closeDate,
                              );
                              if (date != null) setState(() => _closeDate = date);
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: _loading ? null : _save,
                      child: Text(_loading ? 'Création...' : 'Créer le sondage'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
