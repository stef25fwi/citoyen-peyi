import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../../../features/registration/domain/registration_code.dart';
import '../../../shared/utils/date_formatters.dart';
import '../../../shared/widgets/app_scaffold.dart';
import '../../../shared/widgets/section_title.dart';
import '../../../state/app_state.dart';

class AdminRegistrationsPage extends StatefulWidget {
  const AdminRegistrationsPage({super.key});

  @override
  State<AdminRegistrationsPage> createState() => _AdminRegistrationsPageState();
}

class _AdminRegistrationsPageState extends State<AdminRegistrationsPage> {
  String? _selectedPollId;
  final _bulkCount = TextEditingController(text: '20');
  final _validateController = TextEditingController();
  final _documentTypeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final polls = state.polls;
    _selectedPollId ??= polls.isNotEmpty ? polls.first.id : null;
    final selectedCodes = state.registrationCodes
        .where((e) => _selectedPollId == null || e.pollId == _selectedPollId)
        .toList();

    return AppScaffold(
      title: 'Inscriptions et codes',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionTitle(
            title: 'Gestion des accès',
            subtitle: 'Créer des codes et les valider côté contrôleur.',
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  DropdownButtonFormField<String>(
                    value: _selectedPollId,
                    items: polls
                        .map((e) => DropdownMenuItem(value: e.id, child: Text(e.projectTitle)))
                        .toList(),
                    onChanged: (value) => setState(() => _selectedPollId = value),
                    decoration: const InputDecoration(labelText: 'Sondage'),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _bulkCount,
                          keyboardType: TextInputType.number,
                          decoration: const InputDecoration(labelText: 'Nombre de codes'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _selectedPollId == null
                              ? null
                              : () async {
                                  await context.read<AppState>().generateRegistrationCodes(
                                        pollId: _selectedPollId!,
                                        count: int.tryParse(_bulkCount.text) ?? 0,
                                      );
                                },
                          icon: const Icon(Icons.qr_code_2),
                          label: const Text('Générer'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                children: [
                  TextField(
                    controller: _validateController,
                    decoration: const InputDecoration(labelText: 'Code à valider'),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _documentTypeController,
                    decoration: const InputDecoration(labelText: 'Type de document'),
                  ),
                  const SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: () async {
                      try {
                        await context.read<AppState>().markCodeValidated(
                              code: _validateController.text,
                              documentType: _documentTypeController.text.trim().isEmpty
                                  ? null
                                  : _documentTypeController.text.trim(),
                            );
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Code validé.')),
                        );
                      } catch (e) {
                        if (!context.mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))),
                        );
                      }
                    },
                    icon: const Icon(Icons.verified_user_outlined),
                    label: const Text('Valider le code'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            '${selectedCodes.length} code(s)',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w800,
                ),
          ),
          const SizedBox(height: 12),
          if (selectedCodes.isEmpty)
            const Card(
              child: Padding(
                padding: EdgeInsets.all(18),
                child: Text('Aucun code disponible pour ce sondage.'),
              ),
            )
          else
            ...selectedCodes.map((code) => _RegistrationCodeCard(code: code)),
        ],
      ),
    );
  }
}

class _RegistrationCodeCard extends StatelessWidget {
  final RegistrationCode code;

  const _RegistrationCodeCard({
    required this.code,
  });

  @override
  Widget build(BuildContext context) {
    final statusText = switch (code.status) {
      RegistrationCodeStatus.available => 'Disponible',
      RegistrationCodeStatus.assigned => 'Attribué',
      RegistrationCodeStatus.validated => 'Validé',
    };

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Card(
        child: ExpansionTile(
          title: Text(code.code, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text('$statusText • créé le ${formatDate(code.createdAt)}'),
          childrenPadding: const EdgeInsets.fromLTRB(18, 0, 18, 18),
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Expire le ${formatDate(code.expiresAt)}\n'
                    'Document : ${code.documentType ?? '—'}\n'
                    'Contrôleur : ${code.verifiedByControllerLabel ?? '—'}',
                  ),
                ),
                QrImageView(
                  data: code.qrPayload ?? code.code,
                  size: 92,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
