import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../features/polls/domain/poll.dart';
import '../../../shared/widgets/app_scaffold.dart';
import '../../../shared/widgets/section_title.dart';
import '../../../state/app_state.dart';

class AdminAnalyticsPage extends StatelessWidget {
  const AdminAnalyticsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final polls = context.watch<AppState>().polls;
    final active = polls.where((e) => e.status == PollStatus.active).length;
    final closed = polls.where((e) => e.status == PollStatus.closed).length;
    final draft = polls.where((e) => e.status == PollStatus.draft).length;

    return AppScaffold(
      title: 'Analytiques',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SectionTitle(
            title: 'Répartition des sondages',
            subtitle: 'Vue rapide de l’état du parc de consultations.',
          ),
          const SizedBox(height: 16),
          Card(
            child: SizedBox(
              height: 280,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: PieChart(
                  PieChartData(
                    sectionsSpace: 2,
                    centerSpaceRadius: 52,
                    sections: [
                      PieChartSectionData(value: active.toDouble(), title: 'En cours\n$active', color: const Color(0xFF0F9D58), radius: 70),
                      PieChartSectionData(value: closed.toDouble(), title: 'Terminés\n$closed', color: const Color(0xFFF4A100), radius: 70),
                      PieChartSectionData(value: draft.toDouble(), title: 'Brouillons\n$draft', color: const Color(0xFF0B6FA4), radius: 70),
                    ],
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 20),
          const SectionTitle(
            title: 'Participation par sondage',
            subtitle: 'Taux de participation calculé à partir des codes votés.',
          ),
          const SizedBox(height: 16),
          Card(
            child: SizedBox(
              height: 340,
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: BarChart(
                  BarChartData(
                    alignment: BarChartAlignment.spaceAround,
                    maxY: 100,
                    titlesData: FlTitlesData(
                      rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 36,
                          getTitlesWidget: (value, meta) => Text('${value.toInt()}%'),
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 64,
                          getTitlesWidget: (value, meta) {
                            final index = value.toInt();
                            if (index < 0 || index >= polls.length) return const SizedBox.shrink();
                            return Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: SizedBox(
                                width: 90,
                                child: Text(
                                  polls[index].projectTitle,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  textAlign: TextAlign.center,
                                  style: const TextStyle(fontSize: 11),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                    barGroups: List.generate(
                      polls.length,
                      (index) {
                        final rate = polls[index].participationRate * 100;
                        return BarChartGroupData(
                          x: index,
                          barRods: [
                            BarChartRodData(
                              toY: rate,
                              borderRadius: BorderRadius.circular(8),
                              color: const Color(0xFF0B6FA4),
                              width: 24,
                            ),
                          ],
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
