import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../shared/widgets/app_scaffold.dart';

class QrAccessPage extends StatefulWidget {
  const QrAccessPage({super.key});

  @override
  State<QrAccessPage> createState() => _QrAccessPageState();
}

class _QrAccessPageState extends State<QrAccessPage> {
  final _controller = TextEditingController();

  void _submit() {
    final code = _controller.text.trim().toUpperCase();
    if (code.isEmpty) return;
    context.go('/vote/$code');
  }

  @override
  Widget build(BuildContext context) {
    return AppScaffold(
      title: 'Accéder avec un code',
      showBottomNav: true,
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  const Icon(Icons.qr_code_scanner_outlined, size: 56, color: Color(0xFF0B6FA4)),
                  const SizedBox(height: 16),
                  Text(
                    'Entrez votre code ou votre token QR',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.w800,
                        ),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  TextField(
                    controller: _controller,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      labelText: 'Ex. INS-AB12CD',
                    ),
                    onSubmitted: (_) => _submit(),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: _submit,
                    icon: const Icon(Icons.arrow_forward),
                    label: const Text('Accéder au vote'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
