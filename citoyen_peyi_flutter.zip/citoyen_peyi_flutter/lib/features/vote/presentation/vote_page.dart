import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../features/polls/domain/poll.dart';
import '../../../shared/widgets/app_scaffold.dart';
import '../../../state/app_state.dart';

class VotePage extends StatefulWidget {
  final String token;

  const VotePage({
    super.key,
    required this.token,
  });

  @override
  State<VotePage> createState() => _VotePageState();
}

class _VotePageState extends State<VotePage> {
  String? _selectedOptionId;
  bool _submitted = false;

  @override
  Widget build(BuildContext context) {
    final state = context.watch<AppState>();
    final poll = state.findPollByToken(widget.token);
    final registration = state.findRegistrationByToken(widget.token);

    if (poll == null || registration == null) {
      return const AppScaffold(
        title: 'Vote',
        child: Center(
          child: Padding(
            padding: EdgeInsets.all(20),
            child: Text('Code invalide ou sondage introuvable.'),
          ),
        ),
      );
    }

    final alreadyVoted = registration.votedAt != null || _submitted;

    return AppScaffold(
      title: 'Votre vote',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: alreadyVoted
                  ? Column(
                      children: [
                        const Icon(Icons.verified, size: 60, color: Color(0xFF0F9D58)),
                        const SizedBox(height: 12),
                        Text(
                          'Merci, votre vote a été pris en compte.',
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w800,
                              ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    )
                  : Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Chip(label: Text(poll.status.name.toUpperCase())),
                        const SizedBox(height: 12),
                        Text(
                          poll.projectTitle,
                          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                                fontWeight: FontWeight.w900,
                              ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          poll.question,
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: 18),
                        ...poll.options.map(
                          (option) => Padding(
                            padding: const EdgeInsets.only(bottom: 12),
                            child: RadioListTile<String>(
                              value: option.id,
                              groupValue: _selectedOptionId,
                              onChanged: (value) => setState(() => _selectedOptionId = value),
                              title: Text(option.label),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(16),
                                side: const BorderSide(color: Color(0xFFD7E4EC)),
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(height: 8),
                        ElevatedButton(
                          onPressed: _selectedOptionId == null
                              ? null
                              : () async {
                                  try {
                                    await context.read<AppState>().recordVote(
                                          token: widget.token,
                                          optionId: _selectedOptionId!,
                                        );
                                    if (!mounted) return;
                                    setState(() => _submitted = true);
                                  } catch (e) {
                                    if (!mounted) return;
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(
                                        content: Text(
                                          e.toString().replaceFirst('Exception: ', ''),
                                        ),
                                      ),
                                    );
                                  }
                                },
                          child: const Text('Valider mon vote'),
                        ),
                      ],
                    ),
            ),
          ),
          const SizedBox(height: 16),
          _ResultsPreview(poll: poll),
        ],
      ),
    );
  }
}

class _ResultsPreview extends StatelessWidget {
  final Poll poll;

  const _ResultsPreview({required this.poll});

  @override
  Widget build(BuildContext context) {
    final totalVotes = poll.options.fold<int>(0, (sum, item) => sum + item.votes);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Résultats actuels',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w800,
                  ),
            ),
            const SizedBox(height: 14),
            ...poll.options.map((option) {
              final ratio = totalVotes == 0 ? 0.0 : option.votes / totalVotes;
              return Padding(
                padding: const EdgeInsets.only(bottom: 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(option.label),
                    const SizedBox(height: 6),
                    LinearProgressIndicator(value: ratio, minHeight: 10),
                    const SizedBox(height: 6),
                    Text('${(ratio * 100).toStringAsFixed(0)}% • ${option.votes} vote(s)'),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }
}
